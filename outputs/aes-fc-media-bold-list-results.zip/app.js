const cfg = window.AES_CONFIG || {};
const configured = cfg.supabaseUrl && !cfg.supabaseUrl.includes("PASTE_") && cfg.supabaseAnonKey && !cfg.supabaseAnonKey.includes("PASTE_");
const db = configured ? window.supabase.createClient(cfg.supabaseUrl, cfg.supabaseAnonKey) : null;

const ADMIN_PASSWORD = "AESfc2015";
const SIGNUP_PASSWORD = "2015";
const MAP_URL = "https://maps.app.goo.gl/VGiFAjKSD9yt7YuB8";
const STATS_START_DATE = "2026-07-22";
const RESULT_PLAYERS_PER_SIDE = 8;
const TRACKER_PLAYERS_PER_SIDE = 6;
const TRACKER_DRAFT_TABLE = "aesfc_tracker_drafts";
const TRACKER_LOCAL_PREFIX = "aesfc_live_tracker_";
const DEFAULT_RULES_TITLE = "Signup rules";
const DEFAULT_RULES_TEXT = `Only Dino, Igor, Michael and Miro can share the signup sheet link. If you have access to the signup link, please keep it private. This helps us know who has access, keep contact details available, and manage updates properly.

For Wednesday 9 PM games, the signup sheet goes live every Saturday morning.

Please give regulars from our WhatsApp group the first chance to sign up in the first 24 hours of the signup sheet being posted. After the 24 hours, you have the green light for people to sign up additional players.

Please do not share the link with others. If you are signing someone else up, sign them up yourself and include their name in the comments section.

Anyone you sign up is your responsibility. If they, or you, cannot play, tell us and make an effort to find a replacement.`;

const fallbackPhotos = [
  { title: "AES FC match photo 1", url: "public/photos/aes-placeholder-1.svg", caption: "Replace this placeholder in public/photos." },
  { title: "AES FC match photo 2", url: "public/photos/aes-placeholder-2.svg", caption: "Add real game photos in the admin dashboard or public/photos." },
  { title: "AES FC match photo 3", url: "public/photos/aes-placeholder-3.svg", caption: "Mobile-friendly gallery with lightbox preview." }
];

const fallbackResults = [];

const state = {
  photos: fallbackPhotos,
  photoIndex: 0,
  results: fallbackResults,
  games: [],
  signups: [],
  cancelledSignups: [],
  regulars: [],
  game: null,
  realtimeChannel: null,
  realtimeGameId: null,
  liveToastTimer: null,
  tracker: {
    gameDate: "",
    teamA: [],
    teamB: [],
    events: [],
    pendingTeam: null,
    editingIndex: null,
    pendingScorer: "",
    pendingAssist: "",
    lastSavedAt: "",
    saveStatus: "",
    started: false
  },
  settings: {
    rules_title: DEFAULT_RULES_TITLE,
    rules_text: DEFAULT_RULES_TEXT,
    youtube_channel_url: cfg.youtubeChannelUrl || "https://www.youtube.com/@dinovucic239/videos",
    youtube_video_ids: (cfg.youtubeVideoIds || []).join("\n")
  },
  adminPassword: sessionStorage.getItem("aes_admin_password") || ""
};

const el = (id) => document.getElementById(id);
const fmtDate = new Intl.DateTimeFormat("en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "Europe/Zagreb" });
const fmtTime = new Intl.DateTimeFormat("en-GB", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Zagreb" });
const fmtShortGame = new Intl.DateTimeFormat("en-US", { weekday: "short", month: "short", day: "numeric", timeZone: "Europe/Zagreb" });
const fmtShortResult = new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric", timeZone: "Europe/Zagreb" });
const fmtOpenDate = new Intl.DateTimeFormat("en-GB", { weekday: "long", day: "numeric", month: "long", hour: "2-digit", minute: "2-digit", timeZone: "Europe/Zagreb" });

function setMessage(node, message, isError = false) {
  node.textContent = message || "";
  node.classList.toggle("error", Boolean(isError));
}

function escapeHtml(value = "") {
  return String(value).replace(/[&<>"']/g, (char) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[char]));
}

function requireDb() {
  if (!db) throw new Error("Supabase is not connected yet.");
}

function zagrebParts(date = new Date()) {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Europe/Zagreb",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23"
  }).formatToParts(date).reduce((acc, part) => {
    acc[part.type] = part.value;
    return acc;
  }, {});
  const dowMap = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 };
  return {
    date: `${parts.year}-${parts.month}-${parts.day}`,
    hour: Number(parts.hour),
    minute: Number(parts.minute),
    isoDow: dowMap[parts.weekday]
  };
}

function addDays(dateString, days) {
  const date = new Date(`${dateString}T12:00:00Z`);
  date.setUTCDate(date.getUTCDate() + days);
  return date.toISOString().slice(0, 10);
}

function isoDowFromDate(dateString) {
  const date = new Date(`${dateString}T12:00:00Z`);
  const day = date.getUTCDay();
  return day === 0 ? 7 : day;
}

function zagrebOffset(dateString, time = "12:00") {
  const utcGuess = new Date(`${dateString}T${time}:00Z`);
  const zoneName = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Europe/Zagreb",
    timeZoneName: "longOffset"
  }).formatToParts(utcGuess).find((part) => part.type === "timeZoneName")?.value || "GMT+01:00";
  const match = zoneName.match(/GMT([+-])(\d{1,2})(?::?(\d{2}))?/);
  if (!match) return "+01:00";
  return `${match[1]}${match[2].padStart(2, "0")}:${match[3] || "00"}`;
}

function zagrebDateTime(dateString, time = "12:00") {
  const cleanTime = String(time || "12:00").slice(0, 5);
  return `${dateString}T${cleanTime}:00${zagrebOffset(dateString, cleanTime)}`;
}

function signupOpenForGame(gameDate) {
  return zagrebDateTime(addDays(gameDate, -4), "09:00");
}

function toDatetimeLocalValue(value, fallbackDate) {
  const source = value || signupOpenForGame(fallbackDate);
  const date = new Date(source);
  const parts = new Intl.DateTimeFormat("sv-SE", {
    timeZone: "Europe/Zagreb",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false
  }).formatToParts(date).reduce((all, part) => ({ ...all, [part.type]: part.value }), {});
  return `${parts.year}-${parts.month}-${parts.day}T${parts.hour}:${parts.minute}`;
}

function datetimeLocalToZagreb(value) {
  if (!value) return "";
  const [date, time = "09:00"] = String(value).split("T");
  return zagrebDateTime(date, time.slice(0, 5));
}

function getDefaultGameWindow() {
  const now = zagrebParts();
  const monday = addDays(now.date, -(now.isoDow - 1));
  const afterSaturdayOpen = now.isoDow === 6 && (now.hour > 9 || (now.hour === 9 && now.minute >= 0));
  const beforeWednesdayClose = now.isoDow === 3 && now.hour < 22;
  const inCurrentWindow = afterSaturdayOpen || now.isoDow === 7 || now.isoDow === 1 || now.isoDow === 2 || beforeWednesdayClose;
  const gameDate = inCurrentWindow && [1, 2, 3].includes(now.isoDow) ? addDays(monday, 2) : addDays(monday, 9);
  return {
    game_date: gameDate,
    start_time: "21:00",
    end_time: "22:00",
    location_name: "NK Bili As ADB Pitch",
    location_url: MAP_URL,
    signup_opens_at: signupOpenForGame(gameDate)
  };
}

function isGameOpen(game) {
  if (!game) return false;
  const opens = new Date(game.signup_opens_at || signupOpenForGame(game.game_date));
  const closes = new Date(zagrebDateTime(game.game_date, String(game.end_time || "22:00").slice(0, 5)));
  const now = new Date();
  return now >= opens && now < closes;
}

function guestSignupAllowed(game = state.game) {
  if (!game) return false;
  const opens = new Date(game.signup_opens_at || signupOpenForGame(game.game_date));
  return new Date() >= new Date(opens.getTime() + 24 * 60 * 60 * 1000);
}

function rankSignups(signups) {
  return [...signups]
    .filter((signup) => !signup.cancelled_at)
    .sort((a, b) => new Date(a.created_at) - new Date(b.created_at) || String(a.id).localeCompare(String(b.id)))
    .map((signup, index) => ({
      ...signup,
      position: index + 1,
      status: index < 12 ? "Playing" : "Sub"
    }));
}

function splitFullName(fullName) {
  const clean = String(fullName || "").trim().replace(/\s+/g, " ");
  const parts = clean.split(" ");
  return {
    fullName: clean,
    firstName: parts[0] || "",
    lastName: parts.slice(1).join(" ")
  };
}

function sortPlayerNames(names = []) {
  return [...names].filter(Boolean).sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
}

function signupFullName(signup) {
  return splitFullName(`${signup.first_name || ""} ${signup.last_name || ""}`).fullName;
}

function normalizeName(value) {
  return splitFullName(value).fullName.toLocaleLowerCase();
}

function currentSignupNameSet() {
  return new Set(state.signups.map((signup) => normalizeName(signupFullName(signup))).filter(Boolean));
}

function isValidFullName(fullName) {
  return splitFullName(fullName).fullName.split(" ").filter(Boolean).length >= 2;
}

function isKnownRegularName(fullName) {
  const clean = splitFullName(fullName).fullName;
  return state.regulars.some((regular) => regular.full_name === clean);
}

function isAllowedSignupName(fullName, allowGuest = guestSignupAllowed()) {
  return isKnownRegularName(fullName) || (allowGuest && isValidFullName(fullName));
}

async function getCurrentGame() {
  requireDb();
  const games = await loadUpcomingGames();
  const active = games[0];
  if (active) return { ...active, is_open: isGameOpen(active) };

  const defaultGame = getDefaultGameWindow();
  const { data, error: upsertError } = await db
    .from("aesfc_games")
    .upsert(defaultGame, { onConflict: "game_date" })
    .select()
    .single();
  if (upsertError) throw upsertError;
  state.games = [data];
  return { ...data, is_open: isGameOpen(data) };
}

async function loadUpcomingGames() {
  const { data: games, error } = await db
    .from("aesfc_games")
    .select("*")
    .order("game_date", { ascending: true })
    .order("start_time", { ascending: true })
    .limit(30);
  if (error) throw error;
  const now = new Date();
  state.games = (games || []).filter((game) => now < new Date(zagrebDateTime(game.game_date, String(game.end_time || "22:00").slice(0, 5))));
  return state.games;
}

function assertAdmin() {
  if (state.adminPassword !== ADMIN_PASSWORD) throw new Error("Wrong admin password.");
}

async function loadPhotos() {
  const { data, error } = await db
    .from("aesfc_photos")
    .select("*")
    .eq("is_active", true)
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: true })
    .limit(60);
  if (error) throw error;
  return data?.length ? data : fallbackPhotos;
}

async function loadSettings() {
  const { data, error } = await db
    .from("aesfc_settings")
    .select("*")
    .eq("id", true)
    .maybeSingle();
  if (error) throw error;
  return data || state.settings;
}

async function loadRegulars() {
  const { data, error } = await db
    .from("aesfc_regulars")
    .select("*")
    .eq("is_active", true)
    .order("full_name", { ascending: true });
  if (error) throw error;
  return data || [];
}

async function loadSignups(gameId) {
  const { data, error } = await db
    .from("aesfc_signups")
    .select("*")
    .eq("game_id", gameId)
    .is("cancelled_at", null)
    .order("created_at", { ascending: true });
  if (error) throw error;
  return rankSignups(data || []);
}

async function loadCancelledSignups(gameId) {
  const { data, error } = await db
    .from("aesfc_signups")
    .select("*")
    .eq("game_id", gameId)
    .not("cancelled_at", "is", null)
    .order("cancelled_at", { ascending: false });
  if (error) throw error;
  return data || [];
}

async function ensureOrganizerSignups(game) {
  if (!game?.id) return;
  const opens = new Date(game.signup_opens_at || signupOpenForGame(game.game_date));
  const autoSignupTime = opens;
  const closes = new Date(zagrebDateTime(game.game_date, String(game.end_time || "22:00").slice(0, 5)));
  const now = new Date();
  if (now < autoSignupTime || now >= closes) return;

  const { data: guaranteed, error: regularError } = await db
    .from("aesfc_regulars")
    .select("full_name")
    .eq("is_active", true)
    .eq("guaranteed_signup", true)
    .order("full_name", { ascending: true });
  if (regularError) throw regularError;
  const guaranteedNames = (guaranteed || []).map((regular) => regular.full_name).filter(Boolean);
  if (!guaranteedNames.length) return;

  const { data: existing, error: lookupError } = await db
    .from("aesfc_signups")
    .select("first_name,last_name")
    .eq("game_id", game.id);
  if (lookupError) throw lookupError;

  const existingNames = new Set((existing || []).map((signup) => normalizeName(signupFullName(signup))));
  const rows = guaranteedNames
    .filter((name) => !existingNames.has(normalizeName(name)))
    .map((name, index) => {
      const player = splitFullName(name);
      return {
        game_id: game.id,
        signup_group: crypto.randomUUID(),
        first_name: player.firstName,
        last_name: player.lastName,
        email: "not-collected@aesfc.local",
        phone: "not collected",
        comments: "Guaranteed signup",
        signed_up_by: null,
        played_before: "no",
        cancel_token: crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", ""),
        created_at: new Date(autoSignupTime.getTime() + index).toISOString()
      };
    });

  if (!rows.length) return;
  const { error } = await db.from("aesfc_signups").insert(rows);
  if (error) throw error;
}

async function loadResults() {
  const { data, error } = await db
    .from("aesfc_results")
    .select("*")
    .eq("is_active", true)
    .order("game_date", { ascending: false })
    .order("created_at", { ascending: false })
    .limit(50);
  if (error) {
    console.warn("Results table is not ready yet.", error);
    return fallbackResults;
  }
  return data?.length ? data : fallbackResults;
}

function renderVideos() {
  const grid = el("videoGrid");
  const latestResultVideo = (state.results || []).find((result) => extractYouTubeId(result.youtube_url || ""));
  const latestVideoId = latestResultVideo ? extractYouTubeId(latestResultVideo.youtube_url || "") : "";
  document.querySelector(".youtube-button").href = state.settings.youtube_channel_url || cfg.youtubeChannelUrl || "https://www.youtube.com/@dinovucic239/videos";
  if (!latestVideoId) {
    grid.innerHTML = "<p class=\"empty-note\">No match video has been linked to the latest results yet.</p>";
    return;
  }
  grid.innerHTML = `
    <a class="video-card" href="${escapeHtml(latestResultVideo.youtube_url)}" target="_blank" rel="noreferrer" aria-label="Watch latest match video">
      <img src="https://img.youtube.com/vi/${encodeURIComponent(latestVideoId)}/hqdefault.jpg" alt="AES FC match video thumbnail">
    </a>
  `;
}

function resultWinner(result) {
  if (Number(result.team_a_score) === Number(result.team_b_score)) return "draw";
  return Number(result.team_a_score) > Number(result.team_b_score) ? "a" : "b";
}

function renderResults() {
  const results = state.results.length ? state.results : fallbackResults;
  el("recentResults").innerHTML = results.slice(0, 3).map(renderResultCard).join("") || "<p class=\"empty-note\">No match results yet.</p>";
  el("allResultsList").innerHTML = results.map(renderResultRow).join("") || "<p class=\"empty-note\">No match results yet.</p>";
  renderPlayerStats(results);
}

function resultStats(result, playerName) {
  const stats = result.player_stats || {};
  const playerStats = stats[playerName] || stats[normalizeName(playerName)] || {};
  return {
    goals: Number(playerStats.goals || 0),
    assists: Number(playerStats.assists || 0)
  };
}

function resultHasIndividualStats(result) {
  const stats = result.player_stats || {};
  return Object.values(stats).some((entry) => Number(entry?.goals || 0) > 0 || Number(entry?.assists || 0) > 0);
}

function shouldCountStatsResult(result) {
  if (String(result.game_date) < STATS_START_DATE) return false;
  const isScorelessDraw = Number(result.team_a_score) === 0 && Number(result.team_b_score) === 0;
  return resultHasIndividualStats(result) || isScorelessDraw;
}

function calculatePlayerStats(results) {
  const table = new Map();
  const ensure = (name) => {
    const clean = splitFullName(name).fullName;
    if (!table.has(clean)) {
      table.set(clean, { name: clean, appearances: 0, wins: 0, draws: 0, goals: 0, assists: 0, points: 0 });
    }
    return table.get(clean);
  };
  results.filter(shouldCountStatsResult).forEach((result) => {
    const winner = resultWinner(result);
    const sides = [
      { key: "a", players: result.team_a_players || [] },
      { key: "b", players: result.team_b_players || [] }
    ];
    sides.forEach((side) => {
      sortPlayerNames(side.players).forEach((name) => {
        const row = ensure(name);
        const stats = resultStats(result, name);
        row.appearances += 1;
        row.wins += winner === side.key ? 1 : 0;
        row.draws += winner === "draw" ? 1 : 0;
        row.goals += stats.goals;
        row.assists += stats.assists;
      });
    });
  });
  return [...table.values()].map((row) => ({
    ...row,
    points: row.appearances + row.wins + row.draws + row.goals + row.assists
  })).sort((a, b) =>
    b.points - a.points ||
    b.goals - a.goals ||
    b.assists - a.assists ||
    a.name.localeCompare(b.name, undefined, { sensitivity: "base" })
  );
}

function renderPlayerStats(results) {
  const stats = calculatePlayerStats(results);
  const tableMarkup = (rows) => `
    <table class="stats-table">
      <thead><tr><th>Player</th><th>Pts</th><th>Apps</th><th>W</th><th>D</th><th>G</th><th>A</th></tr></thead>
      <tbody>
        ${rows.map((row) => `
          <tr>
            <td>${escapeHtml(row.name)}</td>
            <td><strong>${row.points}</strong></td>
            <td>${row.appearances}</td>
            <td>${row.wins}</td>
            <td>${row.draws}</td>
            <td>${row.goals}</td>
            <td>${row.assists}</td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
  el("playerStatsTable").innerHTML = stats.length ? `
    ${tableMarkup(stats.slice(0, 10))}
    ${stats.length > 10 ? `
      <details class="stats-expand">
        <summary>Expand full stats list</summary>
        ${tableMarkup(stats)}
      </details>
    ` : ""}
  ` : "<p class=\"empty-note\">No player stats yet.</p>";
}

function renderResultCard(result) {
  const winner = resultWinner(result);
  const hasStats = resultHasIndividualStats(result);
  return `
    <article class="result-card">
      <div class="result-head">
        <span>
          ${escapeHtml(formatResultDate(result.game_date))}
          ${hasStats ? "" : "<small>No individual stats available</small>"}
        </span>
        <strong>${escapeHtml(result.team_a_score)}-${escapeHtml(result.team_b_score)}</strong>
      </div>
      <div class="result-teams">
        ${renderResultTeam(result.team_a_players, winner === "draw" ? "draw" : winner === "a" ? "winner" : "", result, true)}
        ${renderResultTeam(result.team_b_players, winner === "draw" ? "draw" : winner === "b" ? "winner" : "", result, true)}
      </div>
      ${renderResultExtras(result)}
    </article>
  `;
}

function renderResultRow(result) {
  const hasStats = resultHasIndividualStats(result);
  return `
    <article class="result-row">
      <strong>
        ${escapeHtml(formatResultDate(result.game_date))}
        ${hasStats ? "" : "<small>No individual stats available</small>"}
      </strong>
      <span class="result-side">${renderResultPlayers(result.team_a_players || [], result, true)}</span>
      <b>${escapeHtml(result.team_a_score)}-${escapeHtml(result.team_b_score)}</b>
      <span class="result-side">${renderResultPlayers(result.team_b_players || [], result, true)}</span>
      ${renderResultExtras(result, true)}
    </article>
  `;
}

function renderResultTeam(players = [], status = "", result = null, abbreviate = false) {
  const label = status === "winner" ? "WINNERS" : status === "draw" ? "DRAW" : "Players";
  return `
    <div class="result-team ${status}">
      <span>${label}</span>
      <p>${renderResultPlayers(players, result, abbreviate)}</p>
    </div>
  `;
}

function displayResultName(name, abbreviate = false) {
  if (!abbreviate) return name;
  const player = splitFullName(name);
  return player.lastName ? `${player.firstName} ${player.lastName.charAt(0)}.` : player.firstName;
}

function renderResultPlayers(players = [], result = null, abbreviate = false) {
  const hasStats = result && resultHasIndividualStats(result);
  return sortPlayerNames(players).map((name) => {
    const displayName = displayResultName(name, abbreviate);
    if (!hasStats) return escapeHtml(displayName);
    const stats = resultStats(result, name);
    const bits = [
      stats.goals ? `${stats.goals}G` : "",
      stats.assists ? `${stats.assists}A` : ""
    ].filter(Boolean);
    return `${escapeHtml(displayName)}${bits.length ? ` <span class="player-stat-chip">(${escapeHtml(bits.join(", "))})</span>` : ""}`;
  }).join(", ");
}

function renderResultExtras(result, compact = false) {
  const flow = String(result.game_flow || "").trim();
  const videoUrl = String(result.youtube_url || "").trim();
  if (!flow && !videoUrl) return "";
  return `
    <details class="${compact ? "result-extras compact-result-extras" : "result-extras"}">
      <summary>View details</summary>
      <div>
        ${flow ? `<p><strong>Flow:</strong> ${escapeHtml(flow)}</p>` : ""}
        ${videoUrl ? `<a class="text-link" href="${escapeHtml(videoUrl)}" target="_blank" rel="noreferrer">Watch video</a>` : ""}
      </div>
    </details>
  `;
}

function formatResultDate(dateString) {
  return fmtDate.format(new Date(`${dateString}T12:00:00+02:00`));
}

function formatShortResultDate(dateString) {
  return fmtShortResult.format(new Date(`${dateString}T12:00:00+02:00`));
}

function extractYouTubeId(value = "") {
  const raw = String(value).trim();
  if (!raw) return "";
  const direct = raw.match(/^[a-zA-Z0-9_-]{11}$/);
  if (direct) return raw;
  const patterns = [
    /youtube\.com\/watch\?[^#]*v=([a-zA-Z0-9_-]{11})/,
    /youtu\.be\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/embed\/([a-zA-Z0-9_-]{11})/
  ];
  for (const pattern of patterns) {
    const match = raw.match(pattern);
    if (match) return match[1];
  }
  return "";
}

function renderRules() {
  const paragraphs = String(state.settings.rules_text || DEFAULT_RULES_TEXT)
    .split(/\n{2,}/)
    .map((paragraph) => paragraph.trim())
    .filter(Boolean);
  const rulesTitle = String(state.settings.rules_title || "").trim();
  el("rulesTitle").textContent = !rulesTitle || rulesTitle.toLowerCase() === "signup rules" ? "Before You Sign Up" : rulesTitle;
  const intro = paragraphs.slice(0, 2);
  const rest = paragraphs.slice(2);
  el("rulesText").innerHTML = `
    <div class="rules-intro">
      ${intro.map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`).join("")}
    </div>
    ${rest.length ? `
      <details class="rules-drawer">
        <summary>Full signup guidelines</summary>
        <div class="rules-full">
          ${rest.map((paragraph) => `<p>${escapeHtml(paragraph)}</p>`).join("")}
        </div>
      </details>
    ` : ""}
  `;
}

function renderPhotos() {
  const photos = state.photos.length ? state.photos : fallbackPhotos;
  state.photoIndex = Math.min(state.photoIndex, photos.length - 1);
  el("photoGrid").innerHTML = photos.map((photo, index) => `
    <button class="photo-card" type="button" data-photo="${index}" aria-label="Open ${escapeHtml(photo.title || "football photo")}">
      <img src="${escapeHtml(photo.url)}" alt="${escapeHtml(photo.title || "AES FC football photo")}">
    </button>
  `).join("");
  showPhoto(state.photoIndex);
  clearInterval(window.aesSlideTimer);
  window.aesSlideTimer = setInterval(() => {
    const latest = state.photos.length ? state.photos : fallbackPhotos;
    if (latest.length > 1) showPhoto(state.photoIndex + 1);
  }, 4200);
}

function showPhoto(index) {
  const photos = state.photos.length ? state.photos : fallbackPhotos;
  if (!photos.length) return;
  state.photoIndex = (index + photos.length) % photos.length;
  document.querySelectorAll(".photo-card").forEach((card, cardIndex) => {
    card.classList.toggle("active", cardIndex === state.photoIndex);
  });
  const photo = photos[state.photoIndex];
  el("heroSlide").src = photo.url;
  el("heroSlide").alt = photo.title || "AES FC football photo";
  if (el("photoCounter")) el("photoCounter").textContent = `Photo ${state.photoIndex + 1} of ${photos.length}`;
}

function renderLists() {
  const playing = state.signups.filter((s) => s.status === "Playing");
  const subs = state.signups.filter((s) => s.status === "Sub");
  el("playingCount").textContent = playing.length;
  el("subsCount").textContent = subs.length;
  el("playingList").innerHTML = playing.map(renderPublicSignup).join("") || "<li>No players yet.</li>";
  el("subsList").innerHTML = subs.map(renderPublicSignup).join("") || "<li>No subs yet.</li>";
}

function renderGameSelector() {
  const wrap = el("gameSelectWrap");
  const select = el("gameSelect");
  if (!wrap || !select) return;
  const games = state.games || [];
  wrap.classList.toggle("hidden", games.length <= 1);
  select.innerHTML = games.map((game) => {
    const start = new Date(zagrebDateTime(game.game_date, String(game.start_time || "21:00").slice(0, 5)));
    const label = `${fmtShortGame.format(start)}, ${formatClock(game.start_time).replace(":00 ", "")} - ${game.location_name || "AES FC"}`;
    return `<option value="${escapeHtml(game.id)}">${escapeHtml(label)}</option>`;
  }).join("");
  if (state.game?.id) select.value = state.game.id;
}

function renderPublicSignup(signup) {
  const signedBy = signup.signed_up_by || String(signup.comments || "").match(/^Signed up by (.+)\.$/i)?.[1];
  return `
    <li>
      <strong>${escapeHtml(signup.first_name)} ${escapeHtml(signup.last_name || "")}</strong>
      <span class="meta">
        <span>${fmtTime.format(new Date(signup.created_at))}</span>
        ${signedBy ? `<span class="signup-note">signed up by ${escapeHtml(signedBy)}</span>` : ""}
      </span>
    </li>
  `;
}

function renderSheetStatus() {
  const game = state.game;
  if (!game) {
    el("gameDate").textContent = "Connect Supabase to load the next game";
    el("listGameSummary").textContent = "Connect Supabase";
    el("sheetStatus").classList.remove("hidden");
    el("sheetStatus").textContent = "The site is ready. Connect Supabase to activate live signups.";
    return;
  }
  const gameStart = new Date(zagrebDateTime(game.game_date, String(game.start_time || "21:00").slice(0, 5)));
  const dateText = fmtDate.format(gameStart);
  const timeText = `${formatClock(game.start_time)} - ${formatClock(game.end_time)}`;
  const locationText = game.location_name || "NK Bili As ADB Pitch";
  const locationUrl = game.location_url || MAP_URL;
  el("gameDate").textContent = dateText;
  el("gameTime").textContent = timeText;
  el("gameLocation").textContent = locationText;
  el("gameLocation").href = locationUrl;
  el("listGameSummary").textContent = `${fmtShortGame.format(gameStart)}, ${formatClock(game.start_time).replace(":00 ", "")}`;
  el("sheetStatus").classList.toggle("hidden", game.is_open);
  el("sheetStatus").textContent = game.is_open
    ? ""
    : `Signup is closed now. It opens ${fmtOpenDate.format(new Date(game.signup_opens_at || signupOpenForGame(game.game_date)))} Europe/Zagreb for ${fmtDate.format(new Date(zagrebDateTime(game.game_date, String(game.start_time || "21:00").slice(0, 5))))}.`;
}

function formatClock(value) {
  if (!value) return "";
  const [hourRaw, minute = "00"] = String(value).split(":");
  const hour = Number(hourRaw);
  const suffix = hour >= 12 ? "PM" : "AM";
  const displayHour = ((hour + 11) % 12) + 1;
  return `${displayHour}:${minute} ${suffix}`;
}

function calendarDateValue(date) {
  return date.toISOString().replace(/[-:]/g, "").replace(/\.\d{3}Z$/, "Z");
}

function calendarEventDetails(game = state.game) {
  const start = new Date(zagrebDateTime(game.game_date, String(game.start_time || "21:00").slice(0, 5)));
  const end = new Date(zagrebDateTime(game.game_date, String(game.end_time || "22:00").slice(0, 5)));
  return {
    title: "AES FC football",
    start,
    end,
    location: game.location_name || "NK Bili As ADB Pitch",
    description: `AES FC weekly football. Location: ${game.location_url || MAP_URL}`
  };
}

function buildIcsContent(game = state.game) {
  const details = calendarEventDetails(game);
  const escapeIcs = (value) => String(value || "")
    .replace(/\\/g, "\\\\")
    .replace(/;/g, "\\;")
    .replace(/,/g, "\\,")
    .replace(/\n/g, "\\n");
  return [
    "BEGIN:VCALENDAR",
    "VERSION:2.0",
    "PRODID:-//AES FC//Weekly Football//EN",
    "BEGIN:VEVENT",
    `UID:aesfc-${game.game_date}@aesfc-split`,
    `DTSTAMP:${calendarDateValue(new Date())}`,
    `DTSTART:${calendarDateValue(details.start)}`,
    `DTEND:${calendarDateValue(details.end)}`,
    `SUMMARY:${escapeIcs(details.title)}`,
    `LOCATION:${escapeIcs(details.location)}`,
    `DESCRIPTION:${escapeIcs(details.description)}`,
    "END:VEVENT",
    "END:VCALENDAR"
  ].join("\r\n");
}

function googleCalendarUrl(game = state.game) {
  const details = calendarEventDetails(game);
  const params = new URLSearchParams({
    action: "TEMPLATE",
    text: details.title,
    dates: `${calendarDateValue(details.start)}/${calendarDateValue(details.end)}`,
    location: details.location,
    details: details.description
  });
  return `https://calendar.google.com/calendar/render?${params.toString()}`;
}

function renderCalendarActions(game = state.game) {
  const wrap = el("calendarActions");
  if (!wrap || !game) return;
  const blob = new Blob([buildIcsContent(game)], { type: "text/calendar;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const fileDate = String(game.game_date || "aesfc-game").replaceAll("-", "");
  wrap.innerHTML = `
    <a class="secondary calendar-button" href="${url}" download="aes-fc-${escapeHtml(fileDate)}.ics">Add to Calendar</a>
    <a class="secondary calendar-button" href="${escapeHtml(googleCalendarUrl(game))}" target="_blank" rel="noreferrer">Open in Google Calendar</a>
  `;
  wrap.classList.remove("hidden");
}

function showLiveToast(message) {
  const toast = el("liveToast");
  if (!toast) return;
  toast.textContent = message;
  toast.classList.remove("hidden");
  clearTimeout(state.liveToastTimer);
  state.liveToastTimer = setTimeout(() => toast.classList.add("hidden"), 5200);
}

async function refreshAfterRealtimeChange(messageBuilder) {
  await loadPublicState();
  const playingCount = state.signups.filter((signup) => signup.status === "Playing").length;
  showLiveToast(messageBuilder(playingCount));
  if (state.adminPassword === ADMIN_PASSWORD && !el("adminTools").classList.contains("hidden")) {
    await loadAdmin();
  }
}

function setupRealtime() {
  if (!db || !state.game?.id) return;
  if (state.realtimeChannel && state.realtimeGameId === state.game.id) return;
  if (state.realtimeChannel) db.removeChannel(state.realtimeChannel);
  state.realtimeGameId = state.game.id;
  state.realtimeChannel = db
    .channel(`aesfc-signups-${state.game.id}`)
    .on("postgres_changes", {
      event: "INSERT",
      schema: "public",
      table: "aesfc_signups",
      filter: `game_id=eq.${state.game.id}`
    }, async (payload) => {
      const name = signupFullName(payload.new);
      if (payload.new?.comments === "Guaranteed signup") {
        await loadPublicState();
        return;
      }
      await refreshAfterRealtimeChange((playingCount) => `${name} signed up - ${playingCount}/12 spots filled`);
    })
    .on("postgres_changes", {
      event: "UPDATE",
      schema: "public",
      table: "aesfc_signups",
      filter: `game_id=eq.${state.game.id}`
    }, async (payload) => {
      if (!payload.new?.cancelled_at || payload.old?.cancelled_at) return;
      const name = signupFullName(payload.new);
      await refreshAfterRealtimeChange((playingCount) => `${name} cancelled - ${playingCount}/12 spots filled`);
    })
    .subscribe();
}

async function loadPublicState() {
  if (!configured) {
    state.photos = fallbackPhotos;
    renderSheetStatus();
    renderPhotos();
    renderLists();
    renderResults();
    renderRules();
    renderCancelSelector();
    renderVideos();
    return;
  }
  state.game = await getCurrentGame();
  await ensureOrganizerSignups(state.game);
  state.signups = await loadSignups(state.game.id);
  state.cancelledSignups = await loadCancelledSignups(state.game.id);
  state.photos = await loadPhotos();
  state.settings = await loadSettings();
  state.regulars = await loadRegulars();
  state.results = await loadResults();
  renderSheetStatus();
  renderGameSelector();
  renderPhotos();
  renderLists();
  renderResults();
  renderRules();
  renderPlayerSelectors();
  renderCancelSelector();
  renderVideos();
  setupRealtime();
}

async function selectPublicGame(gameId) {
  const selected = (state.games || []).find((game) => game.id === gameId);
  if (!selected) return;
  state.game = { ...selected, is_open: isGameOpen(selected) };
  await ensureOrganizerSignups(state.game);
  state.signups = await loadSignups(state.game.id);
  state.cancelledSignups = await loadCancelledSignups(state.game.id);
  renderSheetStatus();
  renderGameSelector();
  renderLists();
  renderPlayerSelectors();
  renderCancelSelector();
  setupRealtime();
}

function renderPlayerSelectors() {
  const signedUpNames = currentSignupNameSet();
  const availableRegulars = state.regulars.filter((regular) => !signedUpNames.has(normalizeName(regular.full_name)));
  const allowGuest = guestSignupAllowed();
  document.querySelectorAll(".player-select").forEach((select) => {
    const current = select.value;
    select.innerHTML = `
      <option value="">Choose a player</option>
      ${availableRegulars.map((regular) => `<option value="${escapeHtml(regular.full_name)}">${escapeHtml(regular.full_name)}</option>`).join("")}
      ${allowGuest ? "<option value=\"__manual\">Not listed - enter manually</option>" : ""}
    `;
    if ([...select.options].some((option) => option.value === current)) select.value = current;
  });
  renderSignupPriorityNote();
  renderResponsibleSelector();
  toggleManualName();
  toggleResponsiblePlayer();
  renderExtraPlayerFields();
  renderCancelSelector();
}

function renderResponsibleSelector() {
  const select = el("responsiblePlayerSelect");
  if (!select) return;
  const current = select.value;
  const allowGuest = guestSignupAllowed();
  select.innerHTML = `
    <option value="">Choose your name</option>
    ${state.regulars.map((regular) => `<option value="${escapeHtml(regular.full_name)}">${escapeHtml(regular.full_name)}</option>`).join("")}
    ${allowGuest ? "<option value=\"__manual\">Not listed - enter manually</option>" : ""}
  `;
  if ([...select.options].some((option) => option.value === current)) select.value = current;
}

function renderSignupPriorityNote() {
  const note = el("signupPriorityNote");
  if (!note) return;
  if (!state.game) {
    note.textContent = "";
    return;
  }
  note.textContent = guestSignupAllowed()
    ? "Guests/manual names are open."
    : "List players only for first 24h. Guests open after.";
}

function renderCancelSelector() {
  const select = el("cancelSignupSelect");
  if (!select) return;
  const current = select.value;
  select.innerHTML = `
    <option value="">${state.signups.length ? "Choose your signup" : "No current signups yet"}</option>
    ${state.signups.map((signup) => `
      <option value="${escapeHtml(signup.id)}">${escapeHtml(signupFullName(signup))} - ${escapeHtml(signup.status)} #${signup.position}</option>
    `).join("")}
  `;
  select.disabled = state.signups.length === 0;
  if ([...select.options].some((option) => option.value === current)) select.value = current;
}

function selectedName(selectName, manualName) {
  const selected = document.querySelector(`[name="${selectName}"]`)?.value || "";
  if (selected === "__manual") return document.querySelector(`[name="${manualName}"]`)?.value || "";
  return selected;
}

function selectedIsManual(selectName) {
  return document.querySelector(`[name="${selectName}"]`)?.value === "__manual";
}

function toggleResponsiblePlayer() {
  const signingForSelf = document.querySelector("[name='signup_for_self']")?.checked !== false;
  el("responsiblePlayerWrap").classList.toggle("hidden", signingForSelf);
  const responsibleSelect = el("responsiblePlayerSelect");
  el("responsibleManualWrap").classList.toggle("hidden", responsibleSelect.value !== "__manual" || signingForSelf);
}

function signedByComment(name) {
  return name ? `Signed up by ${name}.` : null;
}

function getExtraPlayerNames() {
  const count = Number(document.querySelector("[name='player_count']").value || 1);
  const names = [];
  for (let i = 1; i < count; i += 1) {
    names.push(selectedName(`extra_player_${i}_select`, `extra_player_${i}_manual`));
  }
  return names.map((name) => name.trim()).filter(Boolean);
}

async function submitSignup(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const message = el("signupMessage");
  el("calendarActions").classList.add("hidden");
  el("calendarActions").innerHTML = "";
  setMessage(message, "Submitting...");
  const formData = new FormData(form);
  if (String(formData.get("signup_password") || "") !== SIGNUP_PASSWORD) {
    setMessage(message, "Wrong signup password.", true);
    return;
  }
  try {
    const game = state.game || await getCurrentGame();
    const playerCount = Number(formData.get("player_count") || 1);
    const allowGuest = guestSignupAllowed(game);
    const mainName = selectedName("full_name_select", "full_name_manual");
    const extraNames = getExtraPlayerNames();
    const signingForSelf = form.querySelector("[name='signup_for_self']")?.checked !== false;
    const responsibleName = signingForSelf
      ? splitFullName(mainName).fullName
      : splitFullName(selectedName("responsible_player_select", "responsible_player_manual")).fullName;
    const requestedNames = [mainName, ...extraNames].map((name) => splitFullName(name).fullName).filter(Boolean);
    const manualGuestRequested = selectedIsManual("full_name_select") || selectedIsManual("responsible_player_select") || Array.from({ length: Math.max(0, playerCount - 1) }, (_, index) => selectedIsManual(`extra_player_${index + 1}_select`)).some(Boolean);
    const signedUpNames = currentSignupNameSet();
    const alreadySignedUp = requestedNames.find((name) => signedUpNames.has(normalizeName(name)));
    const duplicateInRequest = requestedNames.find((name, index) => requestedNames.findIndex((other) => normalizeName(other) === normalizeName(name)) !== index);
    if (manualGuestRequested && !allowGuest) {
      throw new Error("First 24 hours are for players on the list only. Guest/manual names open after the priority window.");
    }
    if (!isAllowedSignupName(mainName, allowGuest)) {
      throw new Error(allowGuest ? "Please choose or enter your full first and last name." : "Please choose a player from the regulars list during the first 24 hours.");
    }
    if (!responsibleName || !isAllowedSignupName(responsibleName, allowGuest)) {
      throw new Error(signingForSelf ? "Please choose or enter your full first and last name." : "Please choose your own name as the person responsible for this signup.");
    }
    if (playerCount > 1 && extraNames.length < playerCount - 1) {
      throw new Error("Please choose or enter the full name of each extra player.");
    }
    const invalidExtra = extraNames.find((name) => !isAllowedSignupName(name, allowGuest));
    if (invalidExtra) {
      throw new Error(allowGuest ? `Please use a full first and last name for ${invalidExtra}.` : `${invalidExtra} is not on the regulars list. Guest/manual names open after the first 24 hours.`);
    }
    if (alreadySignedUp) {
      throw new Error(`${alreadySignedUp} is already signed up for this game.`);
    }
    if (duplicateInRequest) {
      throw new Error(`${duplicateInRequest} is listed more than once in this signup.`);
    }
    if (!isGameOpen(game)) throw new Error(`Signup is closed. It opens ${fmtOpenDate.format(new Date(game.signup_opens_at || signupOpenForGame(game.game_date)))} Europe/Zagreb.`);

    const token = crypto.randomUUID().replaceAll("-", "") + crypto.randomUUID().replaceAll("-", "");
    const group = crypto.randomUUID();
    const baseTime = Date.now();
    const submitter = splitFullName(mainName);
    const rows = [{
      game_id: game.id,
      signup_group: group,
      first_name: submitter.firstName,
      last_name: submitter.lastName,
      email: "not-collected@aesfc.local",
      phone: "not collected",
      comments: signingForSelf ? null : signedByComment(responsibleName),
      signed_up_by: signingForSelf ? null : responsibleName,
      played_before: "no",
      cancel_token: token,
      created_at: new Date(baseTime).toISOString()
    }];

    extraNames.slice(0, Math.max(0, playerCount - 1)).forEach((name, index) => {
      const player = splitFullName(name);
      rows.push({
        game_id: game.id,
        signup_group: group,
        first_name: player.firstName,
        last_name: player.lastName,
        email: "not-collected@aesfc.local",
        phone: "not collected",
        comments: signedByComment(responsibleName),
        signed_up_by: responsibleName,
        played_before: "no",
        cancel_token: token,
        created_at: new Date(baseTime + index + 1).toISOString()
      });
    });

    const { data, error } = await db.from("aesfc_signups").insert(rows).select();
    if (error) throw error;
    const ranked = rankSignups([...(state.signups || []), ...(data || [])]);
    const firstSpot = ranked.find((signup) => signup.id === data[0].id);
    const countText = rows.length === 1 ? "1 player" : `${rows.length} players`;
    const gameDateText = fmtDate.format(new Date(zagrebDateTime(game.game_date, String(game.start_time || "21:00").slice(0, 5))));
    setMessage(message, `You are signed up for the game on ${gameDateText}. Added ${countText}. First spot is ${firstSpot?.status || "Playing"}. If you need to cancel, use the Cancel signup section on this page.`);
    renderCalendarActions(game);
    form.reset();
    form.player_count.value = "1";
    toggleExtraPlayers();
    renderPlayerSelectors();
    await loadPublicState();
  } catch (error) {
    setMessage(message, error.message, true);
  }
}

async function cancelSignup(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const message = el("cancelSignupMessage");
  const data = new FormData(form);
  setMessage(message, "Cancelling...");
  if (String(data.get("cancel_password") || "") !== SIGNUP_PASSWORD) {
    setMessage(message, "Wrong signup password.", true);
    return;
  }
  const signupId = String(data.get("cancel_signup_id") || "");
  const signup = state.signups.find((item) => item.id === signupId);
  if (!signup) {
    setMessage(message, "Please choose your name from the current signup list.", true);
    return;
  }
  try {
    requireDb();
    const { error } = await db
      .from("aesfc_signups")
      .update({ cancelled_at: new Date().toISOString() })
      .eq("id", signupId)
      .is("cancelled_at", null);
    if (error) throw error;
    form.reset();
    setMessage(message, "You have cancelled your signup. Please message the group to let them know you’ve cancelled. If this was a mistake, sign up again if spots are still available.");
    await loadPublicState();
  } catch (error) {
    setMessage(message, error.message, true);
  }
}

async function tryCancellationFromUrl() {
  const params = new URLSearchParams(location.search);
  const signupId = params.get("signup");
  const token = params.get("cancel");
  if (!signupId || !token || !configured) return;
  if (!confirm("Cancel this signup?")) return;
  try {
    const { data: signup, error: lookupError } = await db
      .from("aesfc_signups")
      .select("signup_group")
      .eq("id", signupId)
      .eq("cancel_token", token)
      .single();
    if (lookupError || !signup) throw new Error("This cancellation link is invalid or the signup was already cancelled.");
    const { error } = await db
      .from("aesfc_signups")
      .update({ cancelled_at: new Date().toISOString() })
      .eq("signup_group", signup.signup_group)
      .eq("cancel_token", token)
      .is("cancelled_at", null);
    if (error) throw error;
    history.replaceState({}, "", location.pathname);
    setMessage(el("signupMessage"), "Your signup has been cancelled.");
    await loadPublicState();
  } catch (error) {
    setMessage(el("signupMessage"), error.message, true);
  }
}

function toggleExtraPlayers() {
  const count = Number(document.querySelector("[name='player_count']").value || 1);
  el("extraPlayersWrap").classList.toggle("hidden", count <= 1);
  el("responsibilityWarning").classList.toggle("hidden", count <= 1);
  renderExtraPlayerFields();
}

function toggleManualName() {
  const mainSelect = document.querySelector("[name='full_name_select']");
  el("manualNameWrap").classList.toggle("hidden", mainSelect.value !== "__manual");
}

function renderExtraPlayerFields() {
  const wrap = el("extraPlayersWrap");
  const count = Number(document.querySelector("[name='player_count']").value || 1);
  if (count <= 1) {
    wrap.innerHTML = "";
    return;
  }
  const existingValues = {};
  wrap.querySelectorAll("select, input").forEach((field) => {
    existingValues[field.name] = field.value;
  });
  wrap.innerHTML = Array.from({ length: count - 1 }, (_, index) => {
    const number = index + 1;
    return `
      <div class="extra-player-row" data-extra-row="${number}">
        <label>Extra player ${number}
          <select name="extra_player_${number}_select" class="player-select extra-select"></select>
        </label>
        <label class="extra-manual hidden">Full name
          <input name="extra_player_${number}_manual" placeholder="First and last name">
        </label>
      </div>
    `;
  }).join("");
  wrap.querySelectorAll(".player-select").forEach((select) => {
    const signedUpNames = currentSignupNameSet();
    const availableRegulars = state.regulars.filter((regular) => !signedUpNames.has(normalizeName(regular.full_name)));
    const allowGuest = guestSignupAllowed();
    select.innerHTML = `
      <option value="">Choose a player</option>
      ${availableRegulars.map((regular) => `<option value="${escapeHtml(regular.full_name)}">${escapeHtml(regular.full_name)}</option>`).join("")}
      ${allowGuest ? "<option value=\"__manual\">Not listed - enter manually</option>" : ""}
    `;
    if (existingValues[select.name]) select.value = existingValues[select.name];
  });
  wrap.querySelectorAll("input").forEach((input) => {
    if (existingValues[input.name]) input.value = existingValues[input.name];
  });
  updateExtraManualVisibility();
}

function updateExtraManualVisibility() {
  el("extraPlayersWrap").querySelectorAll(".extra-player-row").forEach((row) => {
    const select = row.querySelector("select");
    row.querySelector(".extra-manual").classList.toggle("hidden", select.value !== "__manual");
  });
}

function openLightbox(index) {
  const photo = (state.photos.length ? state.photos : fallbackPhotos)[index];
  el("lightboxImage").src = photo.url;
  el("lightboxImage").alt = photo.title || "AES FC photo";
  el("lightboxCaption").textContent = photo.caption || photo.title || "";
  el("lightbox").classList.remove("hidden");
}

async function adminLogin(event) {
  event.preventDefault();
  state.adminPassword = new FormData(event.currentTarget).get("password");
  try {
    assertAdmin();
    await loadAdmin();
    sessionStorage.setItem("aes_admin_password", state.adminPassword);
    el("adminTools").classList.remove("hidden");
    setMessage(el("adminMessage"), "Admin dashboard loaded.");
  } catch (error) {
    setMessage(el("adminMessage"), error.message, true);
  }
}

async function loadAdmin() {
  assertAdmin();
  if (!state.game) state.game = await getCurrentGame();
  renderAdminGame(state.game);
  state.signups = await loadSignups(state.game.id);
  state.cancelledSignups = await loadCancelledSignups(state.game.id);
  state.photos = await loadPhotos();
  state.settings = await loadSettings();
  state.regulars = await loadRegulars();
  state.results = await loadResults();
  renderAdminSignups(state.signups);
  renderAdminCancellations(state.cancelledSignups);
  renderAdminPhotos(state.photos);
  renderAdminSettings();
  renderAdminRegulars();
  renderResultForm();
  renderAdminResults();
  renderPlayerSelectors();
}

function renderAdminGame(game) {
  if (!game) return;
  const gameStart = new Date(zagrebDateTime(game.game_date, String(game.start_time || "21:00").slice(0, 5)));
  el("adminCurrentGame").textContent = `Editing signup for: ${fmtShortGame.format(gameStart)} · ${formatClock(game.start_time).replace(":00 ", "")}`;
  const form = el("gameForm");
  form.game_date.value = game.game_date || "";
  form.start_time.value = String(game.start_time || "21:00").slice(0, 5);
  form.end_time.value = String(game.end_time || "22:00").slice(0, 5);
  form.signup_opens_at.value = toDatetimeLocalValue(game.signup_opens_at, game.game_date);
  form.location_name.value = game.location_name || "NK Bili As ADB Pitch";
  form.location_url.value = game.location_url || MAP_URL;

  const newForm = el("newGameForm");
  const defaultGame = getDefaultGameWindow();
  newForm.game_date.value = defaultGame.game_date;
  newForm.start_time.value = defaultGame.start_time;
  newForm.end_time.value = defaultGame.end_time;
  newForm.signup_opens_at.value = toDatetimeLocalValue(defaultGame.signup_opens_at, defaultGame.game_date);
  newForm.location_name.value = game.location_name || defaultGame.location_name;
  newForm.location_url.value = game.location_url || defaultGame.location_url;
}

function applyDefaultSignupOpen(form) {
  const gameDate = form?.game_date?.value;
  if (!gameDate || !form.signup_opens_at) return;
  form.signup_opens_at.value = toDatetimeLocalValue(signupOpenForGame(gameDate), gameDate);
}

function renderAdminSettings() {
  const form = el("settingsForm");
  form.rules_title.value = state.settings.rules_title || DEFAULT_RULES_TITLE;
  form.rules_text.value = state.settings.rules_text || DEFAULT_RULES_TEXT;
  form.youtube_video_ids.value = state.settings.youtube_video_ids || "";
}

function resultPlayerOptions() {
  const names = state.regulars.map((regular) => regular.full_name).filter(Boolean);
  const firstNamesWithFullNames = new Set(
    names
      .filter((name) => splitFullName(name).lastName)
      .map((name) => splitFullName(name).firstName.toLocaleLowerCase())
  );
  return names
    .filter((name) => {
      const player = splitFullName(name);
      if (!player.lastName && firstNamesWithFullNames.has(player.firstName.toLocaleLowerCase())) return false;
      if (player.lastName.length === 1 && firstNamesWithFullNames.has(player.firstName.toLocaleLowerCase())) return false;
      return true;
    })
    .sort((a, b) => a.localeCompare(b, undefined, { sensitivity: "base" }));
}

function renderResultForm() {
  const options = resultPlayerOptions().map((name) => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join("");
  const selects = (team) => Array.from({ length: RESULT_PLAYERS_PER_SIDE }, (_, index) => `
    <div class="result-player-row">
      <label>Player ${index + 1}
        <select name="${team}_player_${index + 1}_select" data-result-player-select>
          <option value="">Choose player</option>
          ${options}
          <option value="__manual">Not listed - enter manually</option>
        </select>
      </label>
      <label class="result-manual hidden">Manual name
        <input name="${team}_player_${index + 1}_manual" placeholder="Full name">
      </label>
      <label>Goals
        <input name="${team}_player_${index + 1}_goals" type="number" min="0" step="1" inputmode="numeric" pattern="[0-9]*" value="0">
      </label>
      <label>Assists
        <input name="${team}_player_${index + 1}_assists" type="number" min="0" step="1" inputmode="numeric" pattern="[0-9]*" value="0">
      </label>
    </div>
  `).join("");
  el("teamAPlayers").innerHTML = selects("team_a");
  el("teamBPlayers").innerHTML = selects("team_b");
  el("resultForm").game_date.value = state.game?.game_date || new Date().toISOString().slice(0, 10);
  el("resultForm").youtube_url.value = "";
  el("resultFlowEditor").innerHTML = renderFlowEditor("game_flow_step");
}

function resultOptionsHtml(selectedName = "") {
  return resultPlayerOptions().map((name) => (
    `<option value="${escapeHtml(name)}" ${name === selectedName ? "selected" : ""}>${escapeHtml(name)}</option>`
  )).join("");
}

function updateResultManualVisibility() {
  el("resultForm").querySelectorAll(".result-player-row").forEach((row) => {
    const select = row.querySelector("select");
    row.querySelector(".result-manual").classList.toggle("hidden", select.value !== "__manual");
  });
}

function updateSavedResultManualVisibility() {
  el("adminResults").querySelectorAll(".saved-player-row").forEach((row) => {
    const select = row.querySelector("select");
    row.querySelector(".saved-result-manual").classList.toggle("hidden", select.value !== "__manual");
  });
}

function selectedResultName(formData, team, index) {
  const selected = String(formData.get(`${team}_player_${index}_select`) || "").trim();
  if (selected !== "__manual") return selected;
  return String(formData.get(`${team}_player_${index}_manual`) || "").trim();
}

function flowSteps(flow = "") {
  return String(flow || "")
    .split(/\s*(?:→|->|>|,|\n)\s*/)
    .map((step) => step.trim())
    .filter(Boolean);
}

function renderFlowEditor(prefix, flow = "") {
  const steps = flowSteps(flow);
  return Array.from({ length: 14 }, (_, index) => `
    <label>Score ${index + 1}
      <input name="${prefix}_${index + 1}" value="${escapeHtml(steps[index] || "")}" placeholder="${index === 0 ? "1-0" : ""}">
    </label>
  `).join("");
}

function collectFlowFromNode(node, prefix) {
  return Array.from({ length: 14 }, (_, index) => node.querySelector(`[name="${prefix}_${index + 1}"]`)?.value || "")
    .map((step) => step.trim())
    .filter(Boolean)
    .join(" → ");
}

function renderAdminResults() {
  const results = state.results.length ? state.results : fallbackResults;
  el("adminResults").innerHTML = results.map((result) => `
    <details class="admin-result" data-result-row="${result.id}">
      <summary>
        <strong>${escapeHtml(formatShortResultDate(result.game_date))}</strong>
        <span>${escapeHtml(result.team_a_score)}-${escapeHtml(result.team_b_score)}</span>
      </summary>
      <p class="admin-help-text">Edit scores, teams, goals, assists, match flow, or YouTube link. Click “Update published result” when done.</p>
      <details class="form-subdrawer">
        <summary>Match details</summary>
        <div class="result-edit-grid">
          <label>Date<input name="result_game_date" type="date" value="${escapeHtml(result.game_date)}"></label>
          <label>Side 1 score<input name="result_team_a_score" type="number" min="0" step="1" inputmode="numeric" pattern="[0-9]*" value="${escapeHtml(result.team_a_score)}"></label>
          <label>Side 2 score<input name="result_team_b_score" type="number" min="0" step="1" inputmode="numeric" pattern="[0-9]*" value="${escapeHtml(result.team_b_score)}"></label>
          <label>YouTube match link<input name="result_youtube_url" type="url" value="${escapeHtml(result.youtube_url || "")}" placeholder="https://youtube.com/watch?v=..."></label>
        </div>
      </details>
      <details class="flow-drawer">
        <summary>Add/edit flow of the match</summary>
        <div class="flow-editor">${renderFlowEditor("result_flow_step", result.game_flow || "")}</div>
      </details>
      ${renderAdminResultTeam("Side 1", "team_a", result.team_a_players || [], result)}
      ${renderAdminResultTeam("Side 2", "team_b", result.team_b_players || [], result)}
      <div class="admin-result-actions">
        ${String(result.id).startsWith("fallback-") ? "" : `<button class="secondary compact" type="button" data-save-result="${result.id}">Update published result</button>`}
        ${String(result.id).startsWith("fallback-") ? "" : `<button class="icon-button" type="button" data-remove-result="${result.id}">Remove</button>`}
      </div>
    </details>
  `).join("");
  updateSavedResultManualVisibility();
}

function renderAdminResultTeam(label, team, players, result) {
  const rows = [...sortPlayerNames(players)];
  while (rows.length < RESULT_PLAYERS_PER_SIDE) rows.push("");
  const regularNames = resultPlayerOptions();
  return `
    <details class="form-subdrawer saved-result-team">
      <summary>${label} players and stats</summary>
      ${rows.slice(0, RESULT_PLAYERS_PER_SIDE).map((player, index) => {
        const stats = player ? resultStats(result, player) : { goals: 0, assists: 0 };
        const isRegular = regularNames.includes(player);
        return `
          <div class="saved-player-row">
            <label>Player ${index + 1}
              <select name="${team}_saved_player_${index + 1}_select" data-saved-result-player-select>
                <option value="">Choose player</option>
                ${resultOptionsHtml(isRegular ? player : "")}
                <option value="__manual" ${player && !isRegular ? "selected" : ""}>Not listed - enter manually</option>
              </select>
            </label>
            <label class="saved-result-manual hidden">Manual name
              <input name="${team}_saved_player_${index + 1}_manual" value="${escapeHtml(player && !isRegular ? player : "")}" placeholder="Full name">
            </label>
            <label>Goals<input name="${team}_saved_goals_${index + 1}" type="number" min="0" step="1" inputmode="numeric" pattern="[0-9]*" value="${stats.goals}"></label>
            <label>Assists<input name="${team}_saved_assists_${index + 1}" type="number" min="0" step="1" inputmode="numeric" pattern="[0-9]*" value="${stats.assists}"></label>
          </div>
        `;
      }).join("")}
    </details>
  `;
}

function renderAdminSignups(signups) {
  el("adminSignups").innerHTML = `
    <table>
      <thead><tr><th>Status</th><th>Edit player name</th><th>Note</th><th></th></tr></thead>
      <tbody>
        ${signups.map((s) => `
          <tr data-admin-row="${s.id}">
            <td>${escapeHtml(s.status)} #${s.position}</td>
            <td>
              <input name="full_name" value="${escapeHtml(signupFullName(s))}" aria-label="Player full name">
            </td>
            <td><small>${escapeHtml(s.signed_up_by ? `Signed up by ${s.signed_up_by}` : s.comments || "Self signup")}</small></td>
            <td>
              <button class="secondary compact" type="button" data-save-signup="${s.id}">Save</button>
              <button class="icon-button" type="button" data-remove-signup="${s.id}">Remove</button>
            </td>
          </tr>
        `).join("")}
      </tbody>
    </table>
  `;
}

function renderAdminCancellations(signups) {
  el("adminCancellations").innerHTML = `
    <table>
      <thead><tr><th>Player</th><th>Cancelled</th><th>Note</th></tr></thead>
      <tbody>
        ${signups.length ? signups.map((s) => `
          <tr>
            <td>${escapeHtml(signupFullName(s))}</td>
            <td>${escapeHtml(fmtTime.format(new Date(s.cancelled_at)))}</td>
            <td><small>${escapeHtml(s.comments || "")}</small></td>
          </tr>
        `).join("") : "<tr><td colspan=\"3\">No cancellations yet.</td></tr>"}
      </tbody>
    </table>
  `;
}

function renderAdminRegulars() {
  el("adminRegulars").innerHTML = state.regulars.map((regular) => `
    <div class="admin-regular" data-regular-row="${regular.id}">
      <input name="regular_full_name" value="${escapeHtml(regular.full_name)}" aria-label="Regular player full name">
      <label class="toggle-row"><input name="regular_guaranteed" type="checkbox" ${regular.guaranteed_signup ? "checked" : ""}> Guaranteed</label>
      <button class="secondary compact" type="button" data-save-regular="${regular.id}">Save</button>
      <button class="icon-button" type="button" data-remove-regular="${regular.id}">Remove</button>
    </div>
  `).join("") || "<p>No regular names yet.</p>";
}

function renderAdminPhotos(photos) {
  el("adminPhotos").innerHTML = photos.map((photo) => `
    <div class="admin-photo">
      <img src="${escapeHtml(photo.url)}" alt="${escapeHtml(photo.title || "photo")}">
      <div><strong>${escapeHtml(photo.title || "Untitled")}</strong><br><small>${escapeHtml(photo.url)}</small></div>
      <button class="icon-button" type="button" data-remove-photo="${photo.id}">Remove</button>
    </div>
  `).join("") || "<p>No photos yet.</p>";
}

async function addPhoto(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  let url = String(data.get("url") || "").trim();
  const file = data.get("file");
  if (!url && file && file.size) {
    setMessage(el("adminMessage"), "Preparing photo...");
    url = await fileToCompressedDataUrl(file);
  }
  if (!url) {
    setMessage(el("adminMessage"), "Add a photo path, URL, or uploaded file.", true);
    return;
  }
  try {
    assertAdmin();
    const { error } = await db.from("aesfc_photos").insert({
      title: data.get("title") || "AES FC photo",
      url,
      caption: data.get("caption") || "",
      sort_order: 100 + state.photos.length
    });
    if (error) throw error;
    form.reset();
    setMessage(el("adminMessage"), "Photo added.");
    await loadPublicState();
    await loadAdmin();
  } catch (error) {
    setMessage(el("adminMessage"), error.message, true);
  }
}

async function addRegular(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const fullName = String(new FormData(form).get("regular_name") || "").trim();
  if (!splitFullName(fullName).fullName) {
    setMessage(el("adminMessage"), "Please enter a player name.", true);
    return;
  }
  try {
    assertAdmin();
    const { error } = await db.from("aesfc_regulars").upsert({
      full_name: splitFullName(fullName).fullName,
      is_active: true,
      sort_order: 100 + state.regulars.length
    }, { onConflict: "full_name" });
    if (error) throw error;
    form.reset();
    setMessage(el("adminMessage"), "Regular player added.");
    state.regulars = await loadRegulars();
    renderAdminRegulars();
    renderPlayerSelectors();
  } catch (error) {
    setMessage(el("adminMessage"), error.message, true);
  }
}

async function saveGameDetails(event) {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  try {
    assertAdmin();
    const gameDate = String(data.get("game_date") || "");
    const updated = {
      game_date: gameDate,
      start_time: data.get("start_time"),
      end_time: data.get("end_time"),
      location_name: data.get("location_name"),
      location_url: data.get("location_url"),
      signup_opens_at: datetimeLocalToZagreb(data.get("signup_opens_at")) || signupOpenForGame(gameDate)
    };
    const { data: saved, error } = await db
      .from("aesfc_games")
      .update(updated)
      .eq("id", state.game.id)
      .select()
      .single();
    if (error) throw error;
    state.game = { ...saved, is_open: isGameOpen(saved) };
    setMessage(el("adminMessage"), "Game details saved.");
    await loadPublicState();
    await loadAdmin();
  } catch (error) {
    setMessage(el("adminMessage"), error.message, true);
  }
}

async function addGame(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  try {
    assertAdmin();
    const gameDate = String(data.get("game_date") || "");
    const game = {
      game_date: gameDate,
      start_time: data.get("start_time"),
      end_time: data.get("end_time"),
      location_name: data.get("location_name"),
      location_url: data.get("location_url"),
      signup_opens_at: datetimeLocalToZagreb(data.get("signup_opens_at")) || signupOpenForGame(gameDate)
    };
    const { error } = await db
      .from("aesfc_games")
      .upsert(game, { onConflict: "game_date" });
    if (error) throw error;
    form.reset();
    setMessage(el("adminMessage"), "Game added. The site will use the earliest upcoming game as the active signup.");
    await loadPublicState();
    await loadAdmin();
  } catch (error) {
    setMessage(el("adminMessage"), error.message, true);
  }
}

function getResultTeam(formData, team) {
  return Array.from({ length: RESULT_PLAYERS_PER_SIDE }, (_, index) => selectedResultName(formData, team, index + 1))
    .filter(Boolean);
}

function getResultPlayerStats(formData, team, players) {
  return players.reduce((stats, name) => {
    const index = Array.from({ length: RESULT_PLAYERS_PER_SIDE }, (_, i) => i + 1)
      .find((number) => selectedResultName(formData, team, number) === name);
    stats[name] = {
      goals: Number(formData.get(`${team}_player_${index}_goals`) || 0),
      assists: Number(formData.get(`${team}_player_${index}_assists`) || 0)
    };
    return stats;
  }, {});
}

function collectSavedResultTeam(row, team) {
  const players = [];
  const stats = {};
  for (let index = 1; index <= RESULT_PLAYERS_PER_SIDE; index += 1) {
    const selectValue = row.querySelector(`[name="${team}_saved_player_${index}_select"]`)?.value || "";
    const manualValue = row.querySelector(`[name="${team}_saved_player_${index}_manual"]`)?.value || "";
    const name = splitFullName(selectValue === "__manual" ? manualValue : selectValue).fullName;
    if (!name) continue;
    players.push(name);
    stats[name] = {
      goals: Number(row.querySelector(`[name="${team}_saved_goals_${index}"]`)?.value || 0),
      assists: Number(row.querySelector(`[name="${team}_saved_assists_${index}"]`)?.value || 0)
    };
  }
  return { players: sortPlayerNames(players), stats };
}

async function saveExistingResult(resultId) {
  const row = [...document.querySelectorAll("[data-result-row]")]
    .find((node) => node.dataset.resultRow === resultId);
  if (!row) throw new Error("Result row not found. Refresh the dashboard and try again.");
  const teamA = collectSavedResultTeam(row, "team_a");
  const teamB = collectSavedResultTeam(row, "team_b");
  if (!teamA.players.length || !teamB.players.length) throw new Error("Saved results need players on both sides.");
  const { error } = await db.from("aesfc_results").update({
    game_date: row.querySelector("[name='result_game_date']").value,
    team_a_score: Number(row.querySelector("[name='result_team_a_score']").value || 0),
    team_b_score: Number(row.querySelector("[name='result_team_b_score']").value || 0),
    team_a_players: teamA.players,
    team_b_players: teamB.players,
    player_stats: { ...teamA.stats, ...teamB.stats },
    game_flow: collectFlowFromNode(row, "result_flow_step"),
    youtube_url: row.querySelector("[name='result_youtube_url']")?.value || ""
  }).eq("id", resultId);
  if (error) throw error;
  setMessage(el("adminMessage"), "Match result updated.");
}

async function addResult(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const data = new FormData(form);
  const teamA = getResultTeam(data, "team_a");
  const teamB = getResultTeam(data, "team_b");
  if (!teamA.length || !teamB.length) {
    setMessage(el("adminMessage"), "Choose or manually enter players for both sides.", true);
    return;
  }
  try {
    assertAdmin();
    const { error } = await db.from("aesfc_results").upsert({
      game_date: data.get("game_date"),
      team_a_players: sortPlayerNames(teamA),
      team_b_players: sortPlayerNames(teamB),
      team_a_score: Number(data.get("team_a_score")),
      team_b_score: Number(data.get("team_b_score")),
      game_flow: collectFlowFromNode(form, "game_flow_step"),
      youtube_url: data.get("youtube_url") || "",
      player_stats: {
        ...getResultPlayerStats(data, "team_a", teamA),
        ...getResultPlayerStats(data, "team_b", teamB)
      },
      is_active: true
    }, { onConflict: "game_date" });
    if (error) throw error;
    form.reset();
    setMessage(el("adminMessage"), "Match result saved.");
    await loadPublicState();
    await loadAdmin();
  } catch (error) {
    setMessage(el("adminMessage"), error.message, true);
  }
}

async function saveSettings(event) {
  event.preventDefault();
  const data = new FormData(event.currentTarget);
  try {
    assertAdmin();
    const updated = {
      id: true,
      rules_title: data.get("rules_title"),
      rules_text: data.get("rules_text"),
      youtube_channel_url: state.settings.youtube_channel_url || cfg.youtubeChannelUrl || "https://www.youtube.com/@dinovucic239/videos",
      youtube_video_ids: normalizeYouTubeList(data.get("youtube_video_ids") || ""),
      updated_at: new Date().toISOString()
    };
    const { data: saved, error } = await db
      .from("aesfc_settings")
      .upsert(updated, { onConflict: "id" })
      .select()
      .single();
    if (error) throw error;
    state.settings = saved;
    renderRules();
    renderVideos();
    setMessage(el("adminMessage"), "Signup rules and videos saved.");
  } catch (error) {
    setMessage(el("adminMessage"), error.message, true);
  }
}

function normalizeYouTubeList(value) {
  return String(value || "")
    .split(/\r?\n|,/)
    .map((entry) => extractYouTubeId(entry))
    .filter(Boolean)
    .join("\n");
}

function fileToCompressedDataUrl(file) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const reader = new FileReader();
    reader.onload = () => {
      image.onload = () => {
        const maxSize = 1200;
        const scale = Math.min(1, maxSize / Math.max(image.width, image.height));
        const canvas = document.createElement("canvas");
        canvas.width = Math.max(1, Math.round(image.width * scale));
        canvas.height = Math.max(1, Math.round(image.height * scale));
        const context = canvas.getContext("2d");
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.72));
      };
      image.onerror = reject;
      image.src = reader.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

function trackerNames() {
  return trackerNameGroups().all;
}

function trackerNameGroups() {
  const signedUpNames = state.signups
    .map((signup) => signupFullName(signup))
    .map((name) => splitFullName(name).fullName)
    .filter(Boolean);
  const signedUpSet = new Set(signedUpNames.map(normalizeName));
  const remainingNames = state.regulars
    .map((regular) => splitFullName(regular.full_name).fullName)
    .filter((name) => name && !signedUpSet.has(normalizeName(name)));
  const signed = signedUpNames.filter((name, index, all) =>
    all.findIndex((other) => normalizeName(other) === normalizeName(name)) === index
  );
  const rest = sortPlayerNames([...new Set(remainingNames)]).filter((name) =>
    !signedUpSet.has(normalizeName(name))
  );
  const all = [
    ...signedUpNames,
    ...rest
  ].filter((name, index, all) => all.findIndex((other) => normalizeName(other) === normalizeName(name)) === index);
  return { signed, rest, all };
}

function trackerLocalKey(gameDate = state.tracker.gameDate || state.game?.game_date || "current") {
  return `${TRACKER_LOCAL_PREFIX}${gameDate}`;
}

function firstNameLabel(fullName) {
  return splitFullName(fullName).firstName || splitFullName(fullName).fullName;
}

function trackerNameLabel(fullName) {
  const player = splitFullName(fullName);
  const allPlayers = [...state.tracker.teamA, ...state.tracker.teamB].map(splitFullName);
  const duplicateFirstName = allPlayers.filter((other) =>
    other.firstName && other.firstName.toLocaleLowerCase() === player.firstName.toLocaleLowerCase()
  ).length > 1;
  if (!duplicateFirstName) return player.firstName || player.fullName;
  const lastInitial = player.lastName ? ` ${player.lastName.charAt(0).toLocaleUpperCase()}.` : "";
  return `${player.firstName}${lastInitial}`.trim() || player.fullName;
}

function trackerDraftPayload(status = "active") {
  return {
    gameDate: state.tracker.gameDate,
    teamA: state.tracker.teamA,
    teamB: state.tracker.teamB,
    events: state.tracker.events,
    started: state.tracker.started,
    status,
    updatedAt: new Date().toISOString()
  };
}

function applyTrackerDraft(draft = {}) {
  state.tracker = {
    gameDate: draft.gameDate || state.game?.game_date || getDefaultGameWindow().game_date,
    teamA: Array.isArray(draft.teamA) ? draft.teamA : [],
    teamB: Array.isArray(draft.teamB) ? draft.teamB : [],
    events: Array.isArray(draft.events) ? draft.events : [],
    pendingTeam: null,
    editingIndex: null,
    pendingScorer: "",
    pendingAssist: "",
    lastSavedAt: draft.updatedAt || "",
    saveStatus: draft.updatedAt ? `Recovered draft saved at ${new Date(draft.updatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}` : "",
    started: Boolean(draft.started)
  };
}

function loadLocalTrackerDraft(gameDate) {
  try {
    const raw = localStorage.getItem(trackerLocalKey(gameDate));
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

async function loadRemoteTrackerDraft(gameDate) {
  if (!db || !gameDate) return null;
  try {
    const { data, error } = await db
      .from(TRACKER_DRAFT_TABLE)
      .select("*")
      .eq("game_date", gameDate)
      .eq("is_finished", false)
      .maybeSingle();
    if (error) throw error;
    return data?.draft_data ? { ...data.draft_data, updatedAt: data.updated_at || data.draft_data.updatedAt } : null;
  } catch {
    return null;
  }
}

async function saveTrackerDraft(status = "Saved") {
  const draft = trackerDraftPayload(status === "Finished" ? "finished" : "active");
  try {
    localStorage.setItem(trackerLocalKey(draft.gameDate), JSON.stringify(draft));
    state.tracker.lastSavedAt = draft.updatedAt;
    state.tracker.saveStatus = `${status} on this device at ${new Date(draft.updatedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    renderTrackerSaveStatus();
  } catch {
    state.tracker.saveStatus = "Could not save on this device.";
    renderTrackerSaveStatus(true);
  }

  if (!db || !draft.gameDate) return;
  try {
    const { error } = await db.from(TRACKER_DRAFT_TABLE).upsert({
      game_date: draft.gameDate,
      draft_data: draft,
      is_finished: draft.status === "finished",
      updated_at: new Date().toISOString()
    }, { onConflict: "game_date" });
    if (error) throw error;
    state.tracker.saveStatus = `${status} online at ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`;
    renderTrackerSaveStatus();
  } catch {
    state.tracker.saveStatus = `${status} on this device. Online draft sync needs the tracker draft SQL.`;
    renderTrackerSaveStatus(true);
  }
}

function clearTrackerDraft(gameDate = state.tracker.gameDate) {
  try {
    localStorage.removeItem(trackerLocalKey(gameDate));
  } catch {
    // Local storage may be unavailable in private browser modes.
  }
}

function renderTrackerTeamSelects() {
  const groups = trackerNameGroups();
  const signedOptions = groups.signed.map((name) => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join("");
  const restOptions = groups.rest.map((name) => `<option value="${escapeHtml(name)}">${escapeHtml(name)}</option>`).join("");
  const rows = (team) => Array.from({ length: TRACKER_PLAYERS_PER_SIDE }, (_, index) => `
    <div class="tracker-team-row">
      <label>Player ${index + 1}
        <select name="tracker_${team}_${index + 1}" data-tracker-player-select>
          <option value="">Choose signed-up player</option>
          ${signedOptions}
          <option value="__more">Expand more players</option>
          <option value="__manual">Manual name</option>
        </select>
      </label>
      <label class="tracker-more-wrap hidden">More players
        <select name="tracker_${team}_${index + 1}_more" data-tracker-more-select>
          <option value="">Choose player</option>
          ${restOptions}
          <option value="__manual">Manual name</option>
        </select>
      </label>
      <label class="tracker-manual-wrap hidden">Manual full name
        <input name="tracker_${team}_${index + 1}_manual" placeholder="First and last name">
      </label>
    </div>
  `).join("");
  el("trackerTeamA").innerHTML = rows("a");
  el("trackerTeamB").innerHTML = rows("b");
  updateTrackerTeamPickerVisibility();
}

function updateTrackerTeamPickerVisibility() {
  document.querySelectorAll(".tracker-team-row").forEach((row) => {
    const select = row.querySelector("[data-tracker-player-select]");
    const moreWrap = row.querySelector(".tracker-more-wrap");
    const moreSelect = row.querySelector("[data-tracker-more-select]");
    const manualWrap = row.querySelector(".tracker-manual-wrap");
    const showMore = select.value === "__more";
    const showManual = select.value === "__manual" || (showMore && moreSelect?.value === "__manual");
    moreWrap.classList.toggle("hidden", !showMore);
    manualWrap.classList.toggle("hidden", !showManual);
  });
}

function selectedTrackerName(team, index) {
  const main = document.querySelector(`[name="tracker_${team}_${index}"]`)?.value || "";
  if (main && main !== "__more" && main !== "__manual") return main;
  if (main === "__more") {
    const more = document.querySelector(`[name="tracker_${team}_${index}_more"]`)?.value || "";
    if (more && more !== "__manual") return more;
  }
  if (main === "__manual" || main === "__more") {
    return document.querySelector(`[name="tracker_${team}_${index}_manual"]`)?.value || "";
  }
  return "";
}

function trackerGoalMinute() {
  const game = state.game || getDefaultGameWindow();
  const gameDate = state.tracker.gameDate || game.game_date;
  const startTime = String(game.start_time || "21:00").slice(0, 5);
  const start = new Date(zagrebDateTime(gameDate, startTime));
  const minute = Math.floor((Date.now() - start.getTime()) / 60000);
  return Math.max(0, Math.min(60, minute));
}

function collectTrackerTeam(team) {
  return Array.from({ length: TRACKER_PLAYERS_PER_SIDE }, (_, index) =>
    splitFullName(selectedTrackerName(team, index + 1)).fullName
  ).filter(Boolean);
}

async function openTracker() {
  assertAdmin();
  const game = state.game || getDefaultGameWindow();
  const gameStart = new Date(zagrebDateTime(game.game_date, String(game.start_time || "21:00").slice(0, 5)));
  el("trackerGameTitle").textContent = `${fmtShortGame.format(gameStart)} · ${formatClock(game.start_time).replace(":00 ", "")}`;
  state.tracker = {
    gameDate: game.game_date,
    teamA: [],
    teamB: [],
    events: [],
    pendingTeam: null,
    editingIndex: null,
    pendingScorer: "",
    pendingAssist: "",
    lastSavedAt: "",
    saveStatus: "",
    started: false
  };
  renderTrackerTeamSelects();
  const localDraft = loadLocalTrackerDraft(game.game_date);
  const remoteDraft = await loadRemoteTrackerDraft(game.game_date);
  const draft = [localDraft, remoteDraft]
    .filter(Boolean)
    .sort((a, b) => new Date(b.updatedAt || 0) - new Date(a.updatedAt || 0))[0];
  if (draft?.events?.length || draft?.started) {
    const savedAt = draft.updatedAt ? ` from ${new Date(draft.updatedAt).toLocaleString()}` : "";
    if (window.confirm(`Resume unfinished live tracker${savedAt}?`)) {
      applyTrackerDraft(draft);
    }
  }
  renderTracker();
  el("liveTracker").classList.remove("hidden");
}

function closeTracker() {
  el("liveTracker").classList.add("hidden");
}

function startTrackerGame() {
  const teamA = collectTrackerTeam("a");
  const teamB = collectTrackerTeam("b");
  const duplicates = teamA.find((name) => teamB.map(normalizeName).includes(normalizeName(name))) ||
    [...teamA, ...teamB].find((name, index, all) => all.findIndex((other) => normalizeName(other) === normalizeName(name)) !== index);
  if (!teamA.length || !teamB.length) {
    setMessage(el("trackerSetupMessage"), "Choose players for both sides before tracking starts.", true);
    return;
  }
  if (duplicates) {
    setMessage(el("trackerSetupMessage"), `${duplicates} is selected more than once.`, true);
    return;
  }
  state.tracker.teamA = teamA;
  state.tracker.teamB = teamB;
  state.tracker.started = true;
  state.tracker.pendingScorer = "";
  state.tracker.pendingAssist = "";
  setMessage(el("trackerSetupMessage"), "");
  renderTracker();
  saveTrackerDraft("Teams saved");
}

function trackerTeamPlayers(team) {
  return team === "a" ? state.tracker.teamA : state.tracker.teamB;
}

function trackerScore(events = state.tracker.events) {
  return events.reduce((score, event) => {
    score[event.team] += 1;
    return score;
  }, { a: 0, b: 0 });
}

function scoreAfterEvent(index, events = state.tracker.events) {
  return trackerScore(events.slice(0, index + 1));
}

function openTrackerGoal(team, editIndex = null) {
  const event = editIndex === null ? null : state.tracker.events[editIndex];
  state.tracker.pendingTeam = team;
  state.tracker.editingIndex = editIndex;
  state.tracker.pendingScorer = event?.scorer || "";
  state.tracker.pendingAssist = event?.assist || "";
  el("trackerGoalTitle").textContent = `${editIndex === null ? "Add" : "Edit"} goal for ${team === "a" ? "Side 1" : "Side 2"}`;
  el("trackerGoalForm").classList.remove("hidden");
  renderTrackerGoalButtons();
}

function renderTrackerGoalButtons() {
  const players = trackerTeamPlayers(state.tracker.pendingTeam);
  el("trackerScorerButtons").innerHTML = players.map((name) => `
    <button class="tracker-player-button${state.tracker.pendingScorer === name ? " selected" : ""}" type="button" data-tracker-scorer="${escapeHtml(name)}">
      ${escapeHtml(trackerNameLabel(name))}
    </button>
  `).join("");
  const assistPlayers = players.filter((name) => name !== state.tracker.pendingScorer);
  el("trackerAssistButtons").innerHTML = `
    <button class="tracker-player-button no-assist${state.tracker.pendingAssist === "" ? " selected" : ""}" type="button" data-tracker-assist="">
      No assist
    </button>
    ${assistPlayers.map((name) => `
      <button class="tracker-player-button${state.tracker.pendingAssist === name ? " selected" : ""}" type="button" data-tracker-assist="${escapeHtml(name)}">
        ${escapeHtml(trackerNameLabel(name))}
      </button>
    `).join("")}
  `;
}

function saveTrackerGoal() {
  const team = state.tracker.pendingTeam;
  const scorer = state.tracker.pendingScorer;
  const assist = state.tracker.pendingAssist;
  if (!team || !scorer) {
    setMessage(el("trackerMessage"), "Choose the scorer before saving the goal.", true);
    return;
  }
  const nextEvents = [...state.tracker.events];
  const previousEvent = state.tracker.editingIndex === null ? null : state.tracker.events[state.tracker.editingIndex];
  const event = { team, scorer, assist, minute: previousEvent?.minute ?? trackerGoalMinute() };
  if (state.tracker.editingIndex === null) nextEvents.push(event);
  else nextEvents[state.tracker.editingIndex] = event;
  state.tracker.events = nextEvents;
  state.tracker.pendingTeam = null;
  state.tracker.editingIndex = null;
  state.tracker.pendingScorer = "";
  state.tracker.pendingAssist = "";
  el("trackerGoalForm").classList.add("hidden");
  setMessage(el("trackerMessage"), "");
  renderTracker();
  saveTrackerDraft("Goal saved");
}

function cancelTrackerGoal() {
  state.tracker.pendingTeam = null;
  state.tracker.editingIndex = null;
  state.tracker.pendingScorer = "";
  state.tracker.pendingAssist = "";
  el("trackerGoalForm").classList.add("hidden");
}

function undoTrackerGoal() {
  if (!state.tracker.events.length) return;
  state.tracker.events.pop();
  renderTracker();
  saveTrackerDraft("Undo saved");
}

function renderTrackerEvents() {
  const events = state.tracker.events;
  el("trackerEvents").innerHTML = events.length ? events.map((event, index) => {
    const score = scoreAfterEvent(index);
    return `
      <div class="tracker-event">
        <strong>${Number.isFinite(event.minute) ? `${event.minute}' · ` : ""}${score.a}-${score.b}</strong>
        <span>${escapeHtml(trackerNameLabel(event.scorer))}${event.assist ? `, assist ${escapeHtml(trackerNameLabel(event.assist))}` : ", no assist"}</span>
        <button class="secondary compact" type="button" data-edit-tracker-goal="${index}">Edit</button>
      </div>
    `;
  }).join("") : "<p class=\"empty-note\">No goals tracked yet.</p>";
}

function renderTrackerSaveStatus(isError = false) {
  const node = el("trackerSaveStatus");
  if (!node) return;
  node.textContent = state.tracker.saveStatus || "";
  node.classList.toggle("error", Boolean(isError));
}

function renderTracker() {
  el("trackerSetup").classList.toggle("hidden", state.tracker.started);
  el("trackerActive").classList.toggle("hidden", !state.tracker.started);
  const score = trackerScore();
  el("trackerScoreA").textContent = score.a;
  el("trackerScoreB").textContent = score.b;
  renderTrackerEvents();
  renderTrackerSaveStatus();
}

async function finishTrackerGame() {
  try {
    assertAdmin();
    const game = state.game || getDefaultGameWindow();
    if (!state.tracker.teamA.length || !state.tracker.teamB.length) throw new Error("Choose both teams before publishing.");
    if (!window.confirm("Publish this final result and update stats?")) return;
    const score = trackerScore();
    const flow = state.tracker.events.map((_, index) => {
      const step = scoreAfterEvent(index);
      return `${step.a}-${step.b}`;
    }).join(" → ");
    const stats = {};
    [...state.tracker.teamA, ...state.tracker.teamB].forEach((name) => {
      stats[name] = { goals: 0, assists: 0 };
    });
    state.tracker.events.forEach((event) => {
      stats[event.scorer] = stats[event.scorer] || { goals: 0, assists: 0 };
      stats[event.scorer].goals += 1;
      if (event.assist) {
        stats[event.assist] = stats[event.assist] || { goals: 0, assists: 0 };
        stats[event.assist].assists += 1;
      }
    });
    const existing = state.results.find((result) => result.game_date === game.game_date);
    const { error } = await db.from("aesfc_results").upsert({
      game_date: game.game_date,
      team_a_players: sortPlayerNames(state.tracker.teamA),
      team_b_players: sortPlayerNames(state.tracker.teamB),
      team_a_score: score.a,
      team_b_score: score.b,
      player_stats: stats,
      game_flow: flow,
      youtube_url: existing?.youtube_url || "",
      is_active: true
    }, { onConflict: "game_date" });
    if (error) throw error;
    setMessage(el("trackerMessage"), "Result published. Stats updated once for this game.");
    await saveTrackerDraft("Finished");
    clearTrackerDraft(game.game_date);
    await loadPublicState();
    if (state.adminPassword === ADMIN_PASSWORD && !el("adminTools").classList.contains("hidden")) await loadAdmin();
  } catch (error) {
    setMessage(el("trackerMessage"), error.message, true);
  }
}

function doubleConfirm(actionLabel) {
  return window.confirm(`${actionLabel}\n\nAre you sure?`) &&
    window.confirm(`${actionLabel}\n\nThis is the second confirmation. Continue?`);
}

async function handleAdminClicks(event) {
  const signupId = event.target.dataset.removeSignup;
  const saveSignupId = event.target.dataset.saveSignup;
  const photoId = event.target.dataset.removePhoto;
  const saveRegularId = event.target.dataset.saveRegular;
  const removeRegularId = event.target.dataset.removeRegular;
  const removeResultId = event.target.dataset.removeResult;
  const saveResultId = event.target.dataset.saveResult;
  try {
    assertAdmin();
    if (saveResultId) {
      await saveExistingResult(saveResultId);
    }
    if (saveSignupId) {
      const row = event.target.closest("[data-admin-row]");
      const player = splitFullName(row.querySelector("[name='full_name']").value);
      if (!player.fullName) throw new Error("Please enter a player name.");
      const { error } = await db.from("aesfc_signups").update({
        first_name: player.firstName,
        last_name: player.lastName
      }).eq("id", saveSignupId);
      if (error) throw error;
      setMessage(el("adminMessage"), "Signup updated.");
    }
    if (signupId) {
      if (!doubleConfirm("Remove this signup?")) return;
      const { error } = await db.from("aesfc_signups").update({ cancelled_at: new Date().toISOString() }).eq("id", signupId);
      if (error) throw error;
      setMessage(el("adminMessage"), "Signup removed. The lists have been recalculated.");
    }
    if (photoId) {
      if (!doubleConfirm("Remove this photo from the site?")) return;
      const { error } = await db.from("aesfc_photos").update({ is_active: false }).eq("id", photoId);
      if (error) throw error;
      setMessage(el("adminMessage"), "Photo removed.");
    }
    if (saveRegularId) {
      const row = event.target.closest("[data-regular-row]");
      const fullName = splitFullName(row.querySelector("[name='regular_full_name']").value).fullName;
      if (!fullName) throw new Error("Please enter a player name.");
      const { error } = await db.from("aesfc_regulars").update({
        full_name: fullName,
        guaranteed_signup: row.querySelector("[name='regular_guaranteed']")?.checked || false
      }).eq("id", saveRegularId);
      if (error) throw error;
      setMessage(el("adminMessage"), "Regular player updated.");
    }
    if (removeRegularId) {
      if (!doubleConfirm("Remove this player from the dropdown list?")) return;
      const { error } = await db.from("aesfc_regulars").update({ is_active: false }).eq("id", removeRegularId);
      if (error) throw error;
      setMessage(el("adminMessage"), "Regular player removed from options.");
    }
    if (removeResultId) {
      if (!doubleConfirm("Remove this match result?")) return;
      const { error } = await db.from("aesfc_results").update({ is_active: false }).eq("id", removeResultId);
      if (error) throw error;
      setMessage(el("adminMessage"), "Match result removed.");
    }
    if (signupId || saveSignupId || photoId || saveRegularId || removeRegularId || removeResultId || saveResultId) {
      await loadPublicState();
      await loadAdmin();
    }
  } catch (error) {
    setMessage(el("adminMessage"), error.message, true);
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  document.querySelector("[name='player_count']").addEventListener("input", toggleExtraPlayers);
  document.querySelector("[name='full_name_select']").addEventListener("change", toggleManualName);
  document.querySelector("[name='signup_for_self']").addEventListener("change", toggleResponsiblePlayer);
  el("responsiblePlayerSelect").addEventListener("change", toggleResponsiblePlayer);
  el("extraPlayersWrap").addEventListener("change", (event) => {
    if (event.target.matches("select")) updateExtraManualVisibility();
  });
  el("signupForm").addEventListener("submit", submitSignup);
  el("gameSelect").addEventListener("change", (event) => selectPublicGame(event.currentTarget.value));
  el("cancelSignupForm").addEventListener("submit", cancelSignup);
  el("photoGrid").addEventListener("click", (event) => {
    const card = event.target.closest("[data-photo]");
    if (card) openLightbox(Number(card.dataset.photo));
  });
  el("photoPrev").addEventListener("click", () => showPhoto(state.photoIndex - 1));
  el("photoNext").addEventListener("click", () => showPhoto(state.photoIndex + 1));
  el("openAllResults").addEventListener("click", () => {
    el("allResults").open = true;
  });
  el("closeLightbox").addEventListener("click", () => el("lightbox").classList.add("hidden"));
  el("lightbox").addEventListener("click", (event) => {
    if (event.target.id === "lightbox") el("lightbox").classList.add("hidden");
  });
  el("adminLogin").addEventListener("submit", adminLogin);
  el("gameForm").addEventListener("submit", saveGameDetails);
  el("gameForm").game_date.addEventListener("change", (event) => applyDefaultSignupOpen(event.currentTarget.form));
  el("newGameForm").game_date.addEventListener("change", (event) => applyDefaultSignupOpen(event.currentTarget.form));
  el("newGameForm").addEventListener("submit", addGame);
  el("resultForm").addEventListener("change", (event) => {
    if (event.target.matches("[data-result-player-select]")) updateResultManualVisibility();
  });
  el("resultForm").addEventListener("submit", addResult);
  el("settingsForm").addEventListener("submit", saveSettings);
  el("photoForm").addEventListener("submit", addPhoto);
  el("regularForm").addEventListener("submit", addRegular);
  el("adminTools").addEventListener("click", handleAdminClicks);
  el("adminResults").addEventListener("change", (event) => {
    if (event.target.matches("[data-saved-result-player-select]")) updateSavedResultManualVisibility();
  });
  el("openTracker").addEventListener("click", openTracker);
  el("closeTracker").addEventListener("click", closeTracker);
  el("startTrackerGame").addEventListener("click", startTrackerGame);
  el("trackerSetup").addEventListener("change", (event) => {
    if (event.target.matches("[data-tracker-player-select], [data-tracker-more-select]")) updateTrackerTeamPickerVisibility();
  });
  el("trackerScorerButtons").addEventListener("click", (event) => {
    const button = event.target.closest("[data-tracker-scorer]");
    if (!button) return;
    state.tracker.pendingScorer = button.dataset.trackerScorer;
    if (state.tracker.pendingAssist === state.tracker.pendingScorer) state.tracker.pendingAssist = "";
    renderTrackerGoalButtons();
  });
  el("trackerAssistButtons").addEventListener("click", (event) => {
    const button = event.target.closest("[data-tracker-assist]");
    if (!button) return;
    state.tracker.pendingAssist = button.dataset.trackerAssist;
    renderTrackerGoalButtons();
  });
  el("saveTrackerGoal").addEventListener("click", saveTrackerGoal);
  el("cancelTrackerGoal").addEventListener("click", cancelTrackerGoal);
  el("undoTrackerGoal").addEventListener("click", undoTrackerGoal);
  el("finishTrackerGame").addEventListener("click", finishTrackerGame);
  document.querySelector(".tracker-goal-buttons").addEventListener("click", (event) => {
    const button = event.target.closest("[data-tracker-goal]");
    if (button) openTrackerGoal(button.dataset.trackerGoal);
  });
  el("trackerEvents").addEventListener("click", (event) => {
    const button = event.target.closest("[data-edit-tracker-goal]");
    if (!button) return;
    const index = Number(button.dataset.editTrackerGoal);
    openTrackerGoal(state.tracker.events[index].team, index);
  });
  el("refreshAdmin").addEventListener("click", loadAdmin);
  el("logoutAdmin").addEventListener("click", () => {
    sessionStorage.removeItem("aes_admin_password");
    state.adminPassword = "";
    el("adminTools").classList.add("hidden");
    setMessage(el("adminMessage"), "Logged out.");
  });
  window.addEventListener("beforeunload", (event) => {
    if (!state.tracker.started || !state.tracker.events.length || el("liveTracker")?.classList.contains("hidden")) return;
    event.preventDefault();
    event.returnValue = "";
  });
  renderVideos();
  try {
    await loadPublicState();
    await tryCancellationFromUrl();
  } catch (error) {
    renderSheetStatus();
    renderPhotos();
    renderLists();
    renderResults();
    renderRules();
    setMessage(el("signupMessage"), error.message, true);
  }
});
